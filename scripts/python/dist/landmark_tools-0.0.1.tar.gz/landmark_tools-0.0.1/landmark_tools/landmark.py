
# #
#  \file   `landmark.py`
#  \author Cecilia Mauceri
#  \brief  Load and save landmark files in python
#  
#  Copyright 2023, by the California Institute of Technology. ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged. Any commercial use must be negotiated with the Office of Technology Transfer at the California Institute of Technology.
#  
#  The technical data in this document is controlled under the U.S. Export Regulations; release to foreign persons may require an export authorization.
#  
#  \section updates Update History
#  - Created: 2023-08-22
#  

import numpy as np
import struct

## \brief Unpack a binary matrix into a numpy array
#
# Element types supported:
# d = double
# f = float
# B = uint8
def unpack_matrix(type, size, buffer):
    if type == 'd':
        b_size = 8
    elif type == 'f':
        b_size = 4
    elif type == 'B':
        b_size = 1
    else:
        raise ValueError("Type not supported");

    list_m = []
    bytes_unpacked = 0
    for ii in range(size[1]):
        nbytes = b_size*size[0]
        list_m.append(struct.unpack(type*size[0], buffer[bytes_unpacked:bytes_unpacked+nbytes]))
        bytes_unpacked += nbytes

    return np.array(list_m)

## \brief Pack a numpy array into a bytearray
#
# Works for 1D and 2D matrices
#
# Element types supported:
# d = double
# f = float
# B = uint8
def pack_matrix(type, mat, buffer, offset=0):
    if type == 'd':
        b_size = 8
    elif type == 'f':
        b_size = 4
    elif type == 'B':
        b_size = 1
    else:
        raise ValueError("Type not supported");

    bytes_packed = offset
    if len(mat.shape)==1:
       for jj in range(mat.shape[0]):
            struct.pack_into(type, buffer, bytes_packed, mat[jj])
            bytes_packed += b_size
    else:
        for ii in range(mat.shape[0]):
            for jj in range(mat.shape[1]):
                struct.pack_into(type, buffer, bytes_packed, mat[ii, jj])
                bytes_packed += b_size

    return

class Landmark:

    def __init__(self, lmk_file):
        with open(lmk_file, 'rb') as fp:
            file_data = fp.read()

        bytes_unpacked = 0

        [self.BODY, self.lmk_id, self.num_cols, self.num_rows] = struct.unpack('iiii', file_data[bytes_unpacked:4*4])
        bytes_unpacked += 4*4

        [self.anchor_col, self.anchor_row, self.anchor_latitude, self.anchor_longitude] = struct.unpack('dddd', file_data[bytes_unpacked:bytes_unpacked+4*8])
        bytes_unpacked += 4*8

        [self.reference_body_radius, self.resolution] = struct.unpack('dd', file_data[bytes_unpacked:bytes_unpacked+2*8])
        bytes_unpacked += 2*8

        self.anchor_point = np.array(struct.unpack('ddd', file_data[bytes_unpacked:bytes_unpacked+3*8]))
        bytes_unpacked += 3*8
        
        self.col_row2mapxy = unpack_matrix('d', [3, 2], file_data[bytes_unpacked:])
        bytes_unpacked += (3*2)*8
        
        self.mapxy2col_row = unpack_matrix('d', [3, 2], file_data[bytes_unpacked:])
        bytes_unpacked += (3*2)*8

        self.mapRworld = unpack_matrix('d', [3, 3], file_data[bytes_unpacked:])
        bytes_unpacked += (3*3)*8

        self.map_normal_vector = np.array(struct.unpack('ddd', file_data[bytes_unpacked:bytes_unpacked+3*8]))
        bytes_unpacked += 3*8

        self.map_plane_params = np.array(struct.unpack('dddd', file_data[bytes_unpacked:bytes_unpacked+4*8]))
        bytes_unpacked += 4*8

        self.num_pixels = self.num_cols*self.num_rows;

        self.srm = unpack_matrix('B', [self.num_cols, self.num_rows], file_data[bytes_unpacked:])
        bytes_unpacked += (self.num_pixels)*1

        self.ele = unpack_matrix('f', [self.num_cols, self.num_rows], file_data[bytes_unpacked:])
        bytes_unpacked += (self.num_pixels)*4

    def save(self, lmk_file):
        size = 4*4 + 37*8 + (self.num_pixels)*1 + (self.num_pixels)*4
        file_data = bytearray(size)
        
        bytes_packed = 0
        struct.pack_into('iiii', file_data, bytes_packed, self.BODY, self.lmk_id, self.num_cols, self.num_rows)
        bytes_packed += 4*4

        struct.pack_into('dddd', file_data, bytes_packed, self.anchor_col, self.anchor_row, self.anchor_latitude, self.anchor_longitude)
        bytes_packed += 4*8

        struct.pack_into('dd', file_data, bytes_packed, self.reference_body_radius, self.resolution)
        bytes_packed += 2*8

        pack_matrix('d', self.anchor_point, file_data, bytes_packed)
        bytes_packed += 3*8
        
        pack_matrix('d', self.col_row2mapxy, file_data, bytes_packed)
        bytes_packed += (3*2)*8
        
        pack_matrix('d', self.mapxy2col_row, file_data, bytes_packed)
        bytes_packed += (3*2)*8

        pack_matrix('d', self.mapRworld, file_data, bytes_packed)
        bytes_packed += (3*3)*8

        pack_matrix('d', self.map_normal_vector, file_data, bytes_packed)
        bytes_packed += 3*8

        pack_matrix('d', self.map_plane_params, file_data, bytes_packed) 
        bytes_packed += 4*8

        pack_matrix('B', self.srm, file_data, bytes_packed)
        bytes_packed += (self.num_pixels)*1

        pack_matrix('f', self.ele, file_data, bytes_packed)
        bytes_packed += (self.num_pixels)*4

        with open(lmk_file, 'wb') as fp:
            fp.write(file_data)

    def __eq__(self, other):
        if isinstance(other, Landmark):
            return self.BODY == other.BODY and \
                self.lmk_id == other.lmk_id and \
                self.num_cols == other.num_cols and \
                self.num_rows == other.num_rows and \
                self.anchor_col == other.anchor_col and \
                self.anchor_row == other.anchor_row and \
                self.anchor_latitude == other.anchor_latitude and \
                self.anchor_longitude == other.anchor_longitude and \
                self.reference_body_radius == other.reference_body_radius and \
                self.resolution == other.resolution and \
                np.all(self.anchor_point == other.anchor_point) and \
                np.all(self.col_row2mapxy == other.col_row2mapxy) and \
                np.all(self.mapxy2col_row == other.mapxy2col_row) and \
                np.all(self.mapRworld == other.mapRworld) and \
                np.all(self.map_normal_vector == other.map_normal_vector) and \
                np.all(self.map_plane_params == other.map_plane_params) and \
                np.all(self.srm == other.srm) and \
                np.all(self.ele == other.ele)
        return NotImplemented