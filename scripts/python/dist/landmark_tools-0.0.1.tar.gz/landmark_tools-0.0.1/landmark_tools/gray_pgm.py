import numpy as np
import cv2
import argparse

parser = argparse.ArgumentParser(description = 'Saves a pgm with size width x height and 125 value at every pixel')

parser.add_argument('filename')          
parser.add_argument('width', type=int)  
parser.add_argument('height', type=int)  

args = parser.parse_args()

X = 125*np.ones((args.height, args.width))
cv2.imwrite(args.filename, X, (cv2.IMWRITE_PXM_BINARY, 1))
 