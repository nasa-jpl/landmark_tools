import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 14})

import numpy as np
from PIL import Image

def readBinaryImage(filename, width, height, dtype='float32'):
    I = np.fromfile(filename, dtype=dtype)
    return np.reshape(I, (width, height)) 

def saveAsImage(I, filename):
    Image.fromarray(I).save(filename)

def visualize_corr(I, output_prefix, title_str, mask, limits=-1):

    if limits == -1:
        m = np.mean(I[~mask])
        sigma = np.std(I[~mask])
        limits = [m-4*sigma, m+4*sigma]

    fig, ax = plt.subplots()
    cax = ax.matshow(I, cmap='BrBG', vmin=limits[0], vmax=limits[1])
    ax.set_title(title_str)
    cbar = fig.colorbar(cax, extend='both')
    cbar.ax.set_ylabel('Meters', rotation=270)

    # Axes
    [h, w] = I.shape
    ax.axis('equal')

    ax.set_ylabel("Pixels")
    ax.set_ylim([0, h])
    
    ax.set_xlabel("Pixels")
    ax.set_xlim([0, w])
    ax.xaxis.set_ticks_position('bottom') # Moves ticks to the bottom
    plt.xticks(rotation=45, ha='right') # Sets tick rotation
    
    # Save
    fig.savefig(output_prefix + '.png')


def corr_histogram(I, output_prefix, title_str, mask, num_bins=50):
    fig = plt.figure()
    plt.subplot(1, 4, (1, 3))

    plt.hist(I[~mask], num_bins)
    plt.xlabel(title_str)
    plt.ylabel('Pixel Count')

    # Plot mean and 3-sigma
    m = np.mean(I[~mask])
    sigma = np.std(I[~mask])
    y0, y1 = plt.ylim()
    half_line = np.floor((y1-y0)/2)
    
    plt.vlines(m, y0, y1, colors='red')
    plt.text(m, y0+half_line, r'mean = {:.2f}'.format(m), rotation=90, ha='right')

    plt.vlines(m-3*sigma, y0, y1, colors='black')
    plt.text(m-3*sigma, y0+half_line, r'mean-3$\sigma$ = {:.2f}'.format(m-3*sigma), rotation=90, ha='right')

    plt.vlines(m+3*sigma, y0, y1, colors='black')
    plt.text(m+3*sigma, y0+half_line, r'mean+3$\sigma$ = {:.2f}'.format(m+3*sigma), rotation=90, ha='right')

    # Text summary
    plt.subplot(1, 4, 4)
    text_summary = 'min : {:.2f}\nmax : {:.2f}\nmean : {:.2f}\nstd ('.format(min(I[~mask]), max(I[~mask]), m) + \
        r'$\sigma$' +  \
        ') : {:.2f}'.format(sigma)
    plt.text(0, 0.5, text_summary)
    plt.axis('off')

    plt.tight_layout()

    plt.savefig(output_prefix + '-histogram.png')

if __name__=='__main__':
    import argparse
    import glob

    parser = argparse.ArgumentParser(
                    prog='VizualizeDEMCorrelation',
                    description='Visualize the output of landmark_comparison')
    parser.add_argument('prefix')
    parser.add_argument('width', type=int)
    parser.add_argument('height', type=int)

    args = parser.parse_args()

    coor_files = glob.glob(args.prefix + "*.raw")
    for filepath in coor_files:
        output_prefix = filepath.replace('.raw', '')
        
        if 'delta_x_' in filepath:
            title = "Delta X";
            limit = [-50, 50];
        elif 'delta_y_' in filepath:
            title = "Delta Y";
            limit = [-50, 50];  
        elif 'delta_z_' in filepath:
            title = "Delta Z";
            limit = [-20, 20];
        else:
            continue
 
        I = readBinaryImage(filepath, args.width, args.height)
        saveAsImage(I, output_prefix+".tif")

        mask = I == 0
        visualize_corr(I, output_prefix, title, mask, limit)
        corr_histogram(I, output_prefix, title, mask)

    print("All figures have been generated.")